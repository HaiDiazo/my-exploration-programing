package com.donatelo.spring.crud.account;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCrudAccountApplicationTests {

	@Test
	void contextLoads() {
	}

}
